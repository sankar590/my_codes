CREATE OR REPLACE PACKAGE BODY glpks_glrglstm_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : glpks_glrglstm_main.sql
     **
     ** Module     : Gen Led
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2025 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Ui_Name                 VARCHAR2(32767);
   g_glrglstm         glpks_glrglstm_Main.ty_glrglstm;
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'glpks_glrglstm_Main ==>'||p_Msg;
         Debug.Pr_Debug('GL' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'GLRGLSTM';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      glpks_glrglstm_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_glrglstm       IN   OUT glpks_glrglstm_Main.ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_MAIN' THEN
            p_glrglstm.v_cstb_ui_columns.CHAR_FIELD1 := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_cstb_ui_columns.CHAR_FIELD11 := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_cstb_ui_columns.CHAR_FIELD12 := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_cstb_ui_columns.CHAR_FIELD13 := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_cstb_ui_columns.CHAR_FIELD14 := Cspks_Req_Global.Fn_GetVal;
         ELSIF  l_Node = 'BLK_REPORT_OPTIONS' THEN
            p_glrglstm.v_rptb_report_options.REPORT_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.FUNCTION_ID := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.REP_FILE_PATH := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.REP_FILE_NAME := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.GEN_MODE := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.REPORT_FORMAT := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.REPORT_OUTPUT := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.PRINT_AT := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.PRINTER_ID := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.PARAM_NAMES := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.PARAM_VALS := Cspks_Req_Global.Fn_GetVal;
            p_glrglstm.v_rptb_report_options.PARAM_TYPES := Cspks_Req_Global.Fn_GetVal;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_glrglstm.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_glrglstm       IN   OUT glpks_glrglstm_Main.ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_MAIN','Main-Full','Main-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'PM_AC_NO' THEN
                  p_glrglstm.v_cstb_ui_columns.CHAR_FIELD1 := l_Val;
               ELSIF l_Key = 'PM_AC_BRANCH' THEN
                  p_glrglstm.v_cstb_ui_columns.CHAR_FIELD11 := l_Val;
               ELSIF l_Key = 'PM_FROM_DATE' THEN
                  p_glrglstm.v_cstb_ui_columns.CHAR_FIELD12 := l_Val;
               ELSIF l_Key = 'PM_TO_DATE' THEN
                  p_glrglstm.v_cstb_ui_columns.CHAR_FIELD13 := l_Val;
               ELSIF l_Key = 'PM_AC_CCY' THEN
                  p_glrglstm.v_cstb_ui_columns.CHAR_FIELD14 := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         ELSIF  l_Node IN ( 'BLK_REPORT_OPTIONS') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'REPREF' THEN
                  p_glrglstm.v_rptb_report_options.REPORT_REF_NO := l_Val;
               ELSIF l_Key = 'REPFID' THEN
                  p_glrglstm.v_rptb_report_options.FUNCTION_ID := l_Val;
               ELSIF l_Key = 'FILEPATH' THEN
                  p_glrglstm.v_rptb_report_options.REP_FILE_PATH := l_Val;
               ELSIF l_Key = 'FILENAME' THEN
                  p_glrglstm.v_rptb_report_options.REP_FILE_NAME := l_Val;
               ELSIF l_Key = 'GENMODE' THEN
                  p_glrglstm.v_rptb_report_options.GEN_MODE := l_Val;
               ELSIF l_Key = 'REPFMT' THEN
                  p_glrglstm.v_rptb_report_options.REPORT_FORMAT := l_Val;
               ELSIF l_Key = 'REPOUTPUT' THEN
                  p_glrglstm.v_rptb_report_options.REPORT_OUTPUT := l_Val;
               ELSIF l_Key = 'PRINTAT' THEN
                  p_glrglstm.v_rptb_report_options.PRINT_AT := l_Val;
               ELSIF l_Key = 'PRINTER' THEN
                  p_glrglstm.v_rptb_report_options.PRINTER_ID := l_Val;
               ELSIF l_Key = 'PARAMNAMES' THEN
                  p_glrglstm.v_rptb_report_options.PARAM_NAMES := l_Val;
               ELSIF l_Key = 'PARAMVALS' THEN
                  p_glrglstm.v_rptb_report_options.PARAM_VALS := l_Val;
               ELSIF l_Key = 'PARAMTYPES' THEN
                  p_glrglstm.v_rptb_report_options.PARAM_TYPES := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_glrglstm.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_glrglstm          IN glpks_glrglstm_Main.ty_glrglstm,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_1_Lvl_Counter := 0;
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_MAIN',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','PM_AC_NO',p_glrglstm.v_cstb_ui_columns.char_field1);
      Cspks_Req_Global.Pr_Write('V','PM_AC_BRANCH',p_glrglstm.v_cstb_ui_columns.char_field11);
      Cspks_Req_Global.Pr_Write('V','PM_FROM_DATE',p_glrglstm.v_cstb_ui_columns.char_field12);
      Cspks_Req_Global.Pr_Write('V','PM_TO_DATE',p_glrglstm.v_cstb_ui_columns.char_field13);
      Cspks_Req_Global.Pr_Write('V','PM_AC_CCY',p_glrglstm.v_cstb_ui_columns.char_field14);

      --Dbg('Building Childs Of :BLK_MAIN..');
      l_Master_Childs  :=  l_Master_Childs +1;
      l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_REPORT_OPTIONS',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','REPREF',p_glrglstm.v_rptb_report_options.report_ref_no);
      Cspks_Req_Global.Pr_Write('V','REPFID',p_glrglstm.v_rptb_report_options.function_id);
      Cspks_Req_Global.Pr_Write('V','FILEPATH',p_glrglstm.v_rptb_report_options.rep_file_path);
      Cspks_Req_Global.Pr_Write('V','FILENAME',p_glrglstm.v_rptb_report_options.rep_file_name);
      Cspks_Req_Global.Pr_Write('V','GENMODE',p_glrglstm.v_rptb_report_options.gen_mode);
      Cspks_Req_Global.Pr_Write('V','REPFMT',p_glrglstm.v_rptb_report_options.report_format);
      Cspks_Req_Global.Pr_Write('V','REPOUTPUT',p_glrglstm.v_rptb_report_options.report_output);
      Cspks_Req_Global.Pr_Write('V','PRINTAT',p_glrglstm.v_rptb_report_options.print_at);
      Cspks_Req_Global.Pr_Write('V','PRINTER',p_glrglstm.v_rptb_report_options.printer_id);
      Cspks_Req_Global.Pr_Write('V','PARAMNAMES',p_glrglstm.v_rptb_report_options.param_names);
      Cspks_Req_Global.Pr_Write('V','PARAMVALS',p_glrglstm.v_rptb_report_options.param_vals);
      Cspks_Req_Global.Pr_Write('V','PARAMTYPES',p_glrglstm.v_rptb_report_options.param_types);
      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_glrglstm          IN glpks_glrglstm_Main.ty_glrglstm,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF (  p_glrglstm.v_cstb_ui_columns.char_field1 IS NOT NULL 
          )
          THEN
            l_1_Lvl_Counter := 0;
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Main-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','PM_AC_NO',p_glrglstm.v_cstb_ui_columns.char_field1);
            Cspks_Req_Global.Pr_Write('V','PM_AC_BRANCH',p_glrglstm.v_cstb_ui_columns.char_field11);
            Cspks_Req_Global.Pr_Write('V','PM_FROM_DATE',p_glrglstm.v_cstb_ui_columns.char_field12);
            Cspks_Req_Global.Pr_Write('V','PM_TO_DATE',p_glrglstm.v_cstb_ui_columns.char_field13);
            Cspks_Req_Global.Pr_Write('V','PM_AC_CCY',p_glrglstm.v_cstb_ui_columns.char_field14);

            --Dbg('Building Childs Of :BLK_MAIN..');
         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Main-PK','1');
         l_Key_Cols := 'PM_AC_NO~';
         l_Key_Vals := p_glrglstm.v_cstb_ui_columns.char_field1||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Get_Params  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Gen_Mode       IN     VARCHAR2,
      p_glrglstm     IN OUT glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Dmy_glrglstm    glpks_glrglstm_Main.Ty_glrglstm;
      l_Chr_Params Cspks_Req_Global.Ty_Tb_Chr_Func_Params;
      l_Param_count      NUMBER := 0;
      l_Val              VARCHAR2(32767);
      l_Multi_Rec_Vals   VARCHAR2(32767);
      l_Fld_Val          VARCHAR2(32767);
      i                  NUMBER:=0;

   BEGIN
      Dbg('In Fn_Sys_Get_Params..');
      IF p_Action_Code = Cspks_Req_Global.P_Default THEN
         p_glrglstm.v_cstb_ui_columns.CHAR_FIELD1 := NULL;
         p_glrglstm.v_cstb_ui_columns.CHAR_FIELD11 := NULL;
         p_glrglstm.v_cstb_ui_columns.CHAR_FIELD12 := NULL;
         p_glrglstm.v_cstb_ui_columns.CHAR_FIELD13 := NULL;
         p_glrglstm.v_cstb_ui_columns.CHAR_FIELD14 := NULL;
         p_glrglstm.v_rptb_report_options.REPORT_REF_NO := NULL;
         p_glrglstm.v_rptb_report_options.FUNCTION_ID := NULL;
         p_glrglstm.v_rptb_report_options.REP_FILE_PATH := NULL;
         p_glrglstm.v_rptb_report_options.REP_FILE_NAME := NULL;
         p_glrglstm.v_rptb_report_options.GEN_MODE := NULL;
         p_glrglstm.v_rptb_report_options.REPORT_FORMAT := NULL;
         p_glrglstm.v_rptb_report_options.REPORT_OUTPUT := NULL;
         p_glrglstm.v_rptb_report_options.PRINT_AT := NULL;
         p_glrglstm.v_rptb_report_options.PRINTER_ID := NULL;
      END IF;
      Dbg('Calling Cspks_Req_Utils. Fn_Get_Report_Params..');
      IF NOT Cspks_Req_Utils.Fn_Get_Report_Params(Global.Current_Branch,
          Global.User_Id ,
          p_Gen_Mode ,
          p_Function_Id ,
          p_Function_Id ,
          l_Chr_Params ,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in   Cspks_Req_Utils.Fn_Get_Report_Params..');
         RETURN FALSE;
      END IF;
      l_Param_count :=  l_Chr_Params.COUNT;
      IF l_Param_count > 0 THEN
         Dbg('Copying Parameters From Maintenance  ..');
         IF l_Chr_Params.EXISTS('PM_AC_NO') THEN
            IF p_glrglstm.v_cstb_ui_columns.CHAR_FIELD1 IS NULL THEN
               p_glrglstm.v_cstb_ui_columns.CHAR_FIELD1 := l_Chr_Params('PM_AC_NO').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('PM_AC_BRANCH') THEN
            IF p_glrglstm.v_cstb_ui_columns.CHAR_FIELD11 IS NULL THEN
               p_glrglstm.v_cstb_ui_columns.CHAR_FIELD11 := l_Chr_Params('PM_AC_BRANCH').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('PM_FROM_DATE') THEN
            IF p_glrglstm.v_cstb_ui_columns.CHAR_FIELD12 IS NULL THEN
               p_glrglstm.v_cstb_ui_columns.CHAR_FIELD12 := l_Chr_Params('PM_FROM_DATE').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('PM_TO_DATE') THEN
            IF p_glrglstm.v_cstb_ui_columns.CHAR_FIELD13 IS NULL THEN
               p_glrglstm.v_cstb_ui_columns.CHAR_FIELD13 := l_Chr_Params('PM_TO_DATE').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('PM_AC_CCY') THEN
            IF p_glrglstm.v_cstb_ui_columns.CHAR_FIELD14 IS NULL THEN
               p_glrglstm.v_cstb_ui_columns.CHAR_FIELD14 := l_Chr_Params('PM_AC_CCY').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('REPREF') THEN
            IF p_glrglstm.v_rptb_report_options.REPORT_REF_NO IS NULL THEN
               p_glrglstm.v_rptb_report_options.REPORT_REF_NO := l_Chr_Params('REPREF').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('REPFID') THEN
            IF p_glrglstm.v_rptb_report_options.FUNCTION_ID IS NULL THEN
               p_glrglstm.v_rptb_report_options.FUNCTION_ID := l_Chr_Params('REPFID').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('FILEPATH') THEN
            IF p_glrglstm.v_rptb_report_options.REP_FILE_PATH IS NULL THEN
               p_glrglstm.v_rptb_report_options.REP_FILE_PATH := l_Chr_Params('FILEPATH').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('FILENAME') THEN
            IF p_glrglstm.v_rptb_report_options.REP_FILE_NAME IS NULL THEN
               p_glrglstm.v_rptb_report_options.REP_FILE_NAME := l_Chr_Params('FILENAME').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('GENMODE') THEN
            IF p_glrglstm.v_rptb_report_options.GEN_MODE IS NULL THEN
               p_glrglstm.v_rptb_report_options.GEN_MODE := l_Chr_Params('GENMODE').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('REPFMT') THEN
            IF p_glrglstm.v_rptb_report_options.REPORT_FORMAT IS NULL THEN
               p_glrglstm.v_rptb_report_options.REPORT_FORMAT := l_Chr_Params('REPFMT').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('REPOUTPUT') THEN
            IF p_glrglstm.v_rptb_report_options.REPORT_OUTPUT IS NULL THEN
               p_glrglstm.v_rptb_report_options.REPORT_OUTPUT := l_Chr_Params('REPOUTPUT').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('PRINTAT') THEN
            IF p_glrglstm.v_rptb_report_options.PRINT_AT IS NULL THEN
               p_glrglstm.v_rptb_report_options.PRINT_AT := l_Chr_Params('PRINTAT').Param_Value;
            END IF;
         END IF;
         IF l_Chr_Params.EXISTS('PRINTER') THEN
            IF p_glrglstm.v_rptb_report_options.PRINTER_ID IS NULL THEN
               p_glrglstm.v_rptb_report_options.PRINTER_ID := l_Chr_Params('PRINTER').Param_Value;
            END IF;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Get_Params ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Get_Params ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Get_Params;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_glrglstm IN  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');


      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'CSTB_UI_COLUMNS';
         l_Fld := 'CSTB_UI_COLUMNS.CHAR_FIELD14';
         IF p_glrglstm.v_cstb_ui_columns.char_field14 IS Null THEN
            Dbg('Mandatory Key Column char_field14 Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_glrglstm     IN  glpks_glrglstm_Main.ty_glrglstm,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_glrglstm     IN  OUT glpks_glrglstm_Main.ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Process  (p_Source          IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_glrglstm     IN  glpks_glrglstm_Main.Ty_glrglstm,
      p_Wrk_glrglstm      IN OUT  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      TYPE ty_multi_rec_list IS TABLE OF VARCHAR2(32767) INDEX BY BINARY_INTEGER;
      l_Param_Names   VARCHAR2(32767) ;
      l_Param_Vals    VARCHAR2(32767) ;
      l_Param_Types   VARCHAR2(32767) ;
      l_multi_rec_list  ty_multi_rec_list ;

   BEGIN

      Dbg('In Fn_Sys_Process..');

      IF p_Action_Code in  (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Default,Cspks_Req_Global.p_Generate ) THEN

         l_Param_Names := 'PM_AC_NO#PM_AC_BRANCH#PM_FROM_DATE#PM_TO_DATE#PM_AC_CCY#REPREF#REPFID#FILEPATH#FILENAME#GENMODE#REPFMT#REPOUTPUT#PRINTAT#PRINTER';
         l_Param_Vals := p_wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD1||'#'||p_wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD11||'#'||p_wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD12||'#'||p_wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD13||'#'||p_wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD14||'#'||p_wrk_glrglstm.v_rptb_report_options.REPORT_REF_NO||'#'||p_wrk_glrglstm.v_rptb_report_options.FUNCTION_ID||'#'||p_wrk_glrglstm.v_rptb_report_options.REP_FILE_PATH||'#'||p_wrk_glrglstm.v_rptb_report_options.REP_FILE_NAME||'#'||p_wrk_glrglstm.v_rptb_report_options.GEN_MODE||'#'||p_wrk_glrglstm.v_rptb_report_options.REPORT_FORMAT||'#'||p_wrk_glrglstm.v_rptb_report_options.REPORT_OUTPUT||'#'||p_wrk_glrglstm.v_rptb_report_options.PRINT_AT||'#'||p_wrk_glrglstm.v_rptb_report_options.PRINTER_ID;
         l_Param_Types := 'VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2#VARCHAR2';

         p_wrk_glrglstm.v_rptb_report_options.PARAM_NAMES := l_Param_Names;
         p_wrk_glrglstm.v_rptb_report_options.PARAM_VALS := l_Param_Vals;
         p_wrk_glrglstm.v_rptb_report_options.PARAM_TYPES := l_Param_Types;
      END IF;
      Dbg('Returning Success From Fn_Sys_Process ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Process ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Process;
   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_glrglstm IN  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_glrglstm     IN  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'CSTB_UI_COLUMNS';
      l_Fld := 'CSTB_UI_COLUMNS.CHAR_FIELD11';
      IF p_wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD11 IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (select branch_code from sttm_branch) WHERE BRANCH_CODE = P_wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD11;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :CHAR_FIELD11:'||p_Wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD11);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_glrglstm.v_cstb_ui_columns.CHAR_FIELD11||'~@CSTB_UI_COLUMNS.CHAR_FIELD11~@CSTB_UI_COLUMNS') ;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_glrglstm     IN  glpks_glrglstm_Main.Ty_glrglstm,
      p_Wrk_glrglstm IN OUT  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      p_Wrk_glrglstm := p_glrglstm;
      IF p_Action_Code in  (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify) THEN
         Dbg('Calling .Fn_Sys_Basic_Vals..');
         IF NOT Fn_Sys_Basic_Vals(p_Source,
            p_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Basic_Vals..');
            RETURN FALSE;
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_New  THEN
            Dbg('Calling .Fn_Sys_Default_Vals..');
            IF NOT Fn_Sys_Default_Vals(p_Source,
               p_Wrk_glrglstm,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in .Fn_Sys_Default_Vals..');
               RETURN FALSE;
            END IF;

         END IF;
         Dbg('Calling .Fn_Sys_Check_Mandatory_Nodes..');
         IF NOT Fn_Sys_Check_Mandatory_Nodes(p_source,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Check_Mandatory_Nodes..');
            RETURN FALSE;
         END IF;

         Dbg('Calling  .Fn_Sys_Lov_Vals..');
         IF NOT Fn_Sys_Lov_Vals(p_source,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Lov_Vals..');
            RETURN FALSE;
         END IF;

      END IF;
      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_glrglstm  IN   OUT glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_glrglstm       IN   OUT glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_GLRGLSTM,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_GLRGLSTM,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_GLRGLSTM,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_glrglstm          IN glpks_glrglstm_Main.ty_glrglstm,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_glrglstm,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_glrglstm,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of glpks_glrglstm_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Params (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Gen_Mode       IN     VARCHAR2,
      p_glrglstm IN OUT  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Blk      VARCHAR2(100) ;
      l_Fld      VARCHAR2(100) ;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation      VARCHAR2(100) := p_Source_Operation;

   BEGIN

      Dbg('In Fn_Get_Params..');

      Pr_Skip_Handler('PREGETPRM');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Pre_Get_Params (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Gen_Mode  ,
            p_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Pre_Get_Params..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT glpks_glrglstm_Main.Fn_Skip_Sys THEN
         IF NOT Fn_Sys_Get_Params(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Gen_Mode  ,
            p_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in pks__Kernel.Fn_Pre_Get_Params..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTGETPRM');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Post_Get_Params (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Gen_Mode  ,
            p_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Post_Get_Params..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Get_Params..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Get_Params ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Params;
   FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_glrglstm IN OUT  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Pk_Or_Full      VARCHAR2(10) :=  'FULL';
      l_Blk      VARCHAR2(100) ;
      l_Fld      VARCHAR2(100) ;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation      VARCHAR2(100) := p_Source_Operation;

   BEGIN

      Dbg('In Fn_Check_Mandatory..');

      IF p_Pk_Or_Full = 'FULL' OR p_Action_Code = Cspks_Req_Global.p_New THEN
         l_Pk_Or_Full := 'FULL';
      ELSE
         l_Pk_Or_Full := p_Pk_Or_Full;
      END IF;
      Pr_Skip_Handler('PREMAND');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  glpks_glrglstm_Custom.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT glpks_glrglstm_Main.Fn_Skip_Sys THEN
         Dbg('Calling   Fn_Sys_Check_Mandatory..');
         IF NOT Fn_Sys_Check_Mandatory(p_Source,
            l_Pk_Or_Full,
            p_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTMAND');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            l_Pk_Or_Full,
            p_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Check_Mandatory;
   FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_glrglstm     IN  glpks_glrglstm_Main.Ty_glrglstm,
      p_Wrk_glrglstm IN OUT  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Check_Amendables  VARCHAR2(1) := 'N';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Pk_Or_Full      VARCHAR2(10) := 'FULL';


   BEGIN

      Dbg('In Fn_Default_And_Validate..');

      Pr_Skip_Handler('PREDFLT');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_glrglstm,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Pre_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT glpks_glrglstm_Main.Fn_Skip_Sys THEN
         Dbg('Calling in Fn_Sys_Default_and_Validate..');
         IF NOT Fn_Sys_Default_and_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_glrglstm,
            p_Wrk_glrglstm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Default_and_Validate..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTDFLT');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Post_Default_And_Validate (p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_glrglstm,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Post_Default_And_Validate ');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Default_And_Validate;
   FUNCTION Fn_Process  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Post_Upl_Stat    IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_glrglstm     IN  glpks_glrglstm_Main.Ty_glrglstm,
      p_Wrk_glrglstm      IN OUT  glpks_glrglstm_Main.Ty_glrglstm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Process..');

      Pr_Skip_Handler('PREUPLD');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Pre_Process (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_Function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_glrglstm,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Pre_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT glpks_glrglstm_Main.Fn_Skip_Sys THEN
         Dbg('Calling  Fn_Sys_Process..');
         IF NOT Fn_Sys_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_glrglstm,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Pre_Process..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTUPLD');
      IF NOT glpks_glrglstm_Main.Fn_Skip_custom  THEN
         IF NOT glpks_glrglstm_Custom.Fn_Post_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_glrglstm,
            p_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in glpks_glrglstm_Custom.Fn_Post_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success  From Fn_Process..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of glpks_glrglstm_Main.Fn_Process ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Process;
   FUNCTION Fn_Main   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_glrglstm          IN OUT glpks_glrglstm_Main.ty_glrglstm,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;
      l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
      l_Post_Upl_Stat         VARCHAR2(1) :='A';
      l_Prev_Auth_Stat        VARCHAR2(1) :='U';
      l_Wrk_glrglstm     glpks_glrglstm_Main.Ty_glrglstm;
      l_Pk_Or_Full    VARCHAR2(5) :='PK';
      l_Count         NUMBER;
      l_Gen_Mode    VARCHAR2(32767);

   BEGIN

      Dbg('In Fn_Main..');

      SAVEPOINT Sp_Main_Glrglstm;
      p_Status := 'S';
      g_glrglstm := p_glrglstm;
      l_Wrk_glrglstm := p_glrglstm;

      l_Gen_Mode   := NVL(p_glrglstm.v_rptb_report_options.Gen_Mode,'M');
      Dbg('Calling  Fn_Get_Params..');
      IF NOT Fn_Get_Params(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Gen_Mode,
         p_glrglstm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Params..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Check_Mandatory..');
      IF NOT Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Pk_Or_Full,
         p_glrglstm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Default_And_Validate..');
      IF NOT Fn_Default_And_Validate (p_Source,
         p_Source_Operation,
         p_Function_Id,
         P_Action_Code,
         p_glrglstm,
         l_Wrk_glrglstm,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Default_And_Validate..');
         pr_log_error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      -- Get Resultant Error Type
      l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
      IF l_Resultant_Error_Type <> 'E' THEN
         Dbg('Calling  Fn_Process..');
         IF NOT Fn_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_glrglstm,
            l_Wrk_glrglstm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Process..');
            pr_log_error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
         --Get Upload Status
         Dbg('Calling  Cspks_Req_Utils.Fn_Get_Upload_Status..');
         IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
            p_source_operation,
            p_Function_Id,
            p_Action_Code,
            p_Multi_Trip_Id,
            P_Request_No,
            l_Post_Upl_Stat,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
            Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         IF l_Post_Upl_Stat IN ('A','U') THEN
            Dbg('Success Case...');
         ELSIF l_Post_Upl_Stat ='O' THEN
            Dbg('Raising Override Exception..');
            RAISE E_Override_Exception;
         ELSE
            Dbg('Not Feasible to Proceed..');
            RAISE E_Failure_Exception;
         END IF;
      ELSE
         Dbg('Encountered Errros..');
         RAISE E_Failure_Exception;
      END IF;

      Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
      Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      g_glrglstm := l_wrk_glrglstm;
      p_glrglstm := l_wrk_glrglstm;
      Dbg('Errors     :'||p_Err_Code);
      Dbg('Parameters :'||p_Err_Params);

      Dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Main..');
         ROLLBACK TO Sp_Main_Glrglstm;
         p_Status        := 'F';
         l_Post_Upl_Stat := 'F';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Main');
         p_Status        := 'O';
         l_post_upl_stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Main ..');
         Debug.Pr_Debug('**',SQLERRM);
         ROLLBACK TO Sp_Main_Glrglstm;
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_glrglstm     glpks_glrglstm_Main.ty_glrglstm;

   BEGIN

      Dbg('In Fn_Process_Request ');
      IF NOT  Fn_Build_Type(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Addl_Info,
         l_glrglstm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_status      := 'F';
         RETURN FALSE;
      END IF;
      IF NOT  Fn_Main(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         l_glrglstm,
         p_Status,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_main..');
         RETURN FALSE;
      END IF;
      p_addl_info := l_glrglstm.Addl_Info;
      IF Cspks_Req_Global.Fn_Build_Resp THEN
         Cspks_Req_Global.Pr_Reset;
         IF NOT  Fn_Build_Ts_List(p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Exchange_Pattern,
            l_glrglstm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Build_Ts_List..');
            p_Status      := 'F';
            RETURN FALSE;
         END IF;
         Cspks_Req_Global.Pr_Close_Ts;
      END IF;
      Dbg('Returning Success From Fn_Process_Request..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_MAIN';
      p_Node_Data(l_Cntr).Xsd_Node := 'Main';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'PM_AC_NO~PM_AC_BRANCH~PM_FROM_DATE~PM_TO_DATE~PM_AC_CCY~';
      p_Node_Data(l_Cntr).Node_Tags := 'PM_AC_NO~PM_AC_BRANCH~PM_FROM_DATE~PM_TO_DATE~PM_AC_CCY~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_REPORT_OPTIONS';
      p_Node_Data(l_Cntr).Xsd_Node := '';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_MAIN';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'REPREF~REPFID~FILEPATH~FILENAME~GENMODE~REPFMT~REPOUTPUT~PRINTAT~PRINTER~PARAMNAMES~PARAMVALS~PARAMTYPES~';
      p_Node_Data(l_Cntr).Node_Tags := 'REPREF~REPFID~FILEPATH~FILENAME~GENMODE~REPFMT~REPOUTPUT~PRINTAT~PRINTER~PARAMNAMES~PARAMVALS~PARAMTYPES~';

      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of glpks_glrglstm_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
END glpks_glrglstm_main;
/